package com.shuai.datebasetest.Service;
import com.shuai.datebasetest.datebase.StudentData;
import com.shuai.datebasetest.datebase.studentinfo;
import org.springframework.stereotype.Service;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.shuai.datebasetest.controller.HelloController;
@Service
public class SweihuService implements StudentService{
    public static String name=null;
    String sql="SELECT * FROM S";
    @Override
    public List<studentinfo> getInfolist() throws Exception {
        List<studentinfo> list=new ArrayList<>();
        try {
            Connection conn=null;
            //加载驱动类
            final String url = "jdbc:mysql://1.116.199.203:3306/shujuku?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
            final String name2 = "com.mysql.cj.jdbc.Driver";
            final String user = "root";
            final String password = "Jenny1210";

            // Connection conn = null;
            Class.forName(name2);//指定连接类型
            conn = DriverManager.getConnection(url, user, password);//获取连接
            if (conn != null) {
                System.out.println("获取连接成功");
                // insert(conn);
            } else {
                System.out.println("获取连接失败");
            }   
            PreparedStatement stmt=conn.prepareStatement("use shujuku");
            stmt.executeQuery();

            stmt=conn.prepareStatement(sql);
            ResultSet rs =stmt.executeQuery();
            while(rs.next()){
                studentinfo student1=new studentinfo();
                student1.setSname(rs.getString("SNAME"));
                name=rs.getString("SNAME");
                System.out.println(rs.getString("SNAME"));
                student1.setSNO(rs.getString("SNO"));
                student1.setAge(rs.getString("AGE"));
                student1.setSex(rs.getString("SEX"));
                student1.setYuanxi(rs.getString("SDEPT"));
                student1.setPssword(rs.getString("password"));
                list.add(student1);
            }

        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return list;
    }
}