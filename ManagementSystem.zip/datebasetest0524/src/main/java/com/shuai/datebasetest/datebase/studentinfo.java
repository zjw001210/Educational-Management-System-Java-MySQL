package com.shuai.datebasetest.datebase;
import com.shuai.datebasetest.bean.*;
import javax.persistence.Entity;
import javax.persistence.Table;
@Entity
@Table(name="studentinfo")
public class studentinfo extends BaseBean{
    private String SNO;
    private String Sname;
    private String Sex;
    private String Age;
    private String yuanxi;
    private String Password;
    public String getSNO(){
        return SNO;
    }
    public void setSNO(String SNO){
        this.SNO=SNO;
    }
    public String getSname(){
        return Sname;
    }
    public void setSname(String Sname){
        this.Sname=Sname;
    }
    public String getSex(){
        return Sex;
    }
    public void setSex(String Sex){
        this.Sex=Sex;
    }
    public String getAge(){
        return Age;
    }
    public void setAge(String Age){
        this.Age=Age;
    }
    public String getYuanxi(){
        return yuanxi;
    }
    public void setYuanxi(String yuanxi){
        this.yuanxi=yuanxi;
    }
    public String getPassword(){
        return Password;
    }
    public void setPssword(String password){
        this.Password=password;
    }
}
