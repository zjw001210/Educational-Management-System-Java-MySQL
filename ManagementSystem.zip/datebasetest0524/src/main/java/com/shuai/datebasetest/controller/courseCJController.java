package com.shuai.datebasetest.controller;
import com.shuai.datebasetest.Service.CJdabiaoService;
import com.shuai.datebasetest.datebase.StudentData;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.shuai.datebasetest.datebase.courseCJ;

import com.shuai.datebasetest.Service.courseCJservice;
@Controller
public class courseCJController {
    @RequestMapping(value = "/Admin2",method = RequestMethod.POST)
    public String Admin2(@RequestParam(value = "heiheihei") String Coursename,Model model) throws Exception {
        courseCJservice coursecJservice=new courseCJservice();
        System.out.println(Coursename);
        List<courseCJ> CJlist=coursecJservice.getInfolist(Coursename);
        model.addAttribute("CJlist",CJlist);
        model.addAttribute("coursename",Coursename);
        return "ADMIN";
    }
}
