package com.shuai.datebasetest.controller;
import com.shuai.datebasetest.datebase.StudentData;
import com.shuai.datebasetest.datebase.pingjunCJ;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
@Controller
public class  CJfenbuController {
    @RequestMapping("/Admin4")
    public String Admin4() throws Exception {
        List<pingjunCJ> list=getchengji();
        System.out.println("list长度"+list.size());
        Test test=new Test();
        test.SHENGCHENG(list);
        return "ffff";
    }
    public List<pingjunCJ> getchengji() throws Exception{
       
        List<pingjunCJ> list=new ArrayList<>();
        try {
            Connection conn=null;
            final String url = "jdbc:mysql://1.116.199.203:3306/shujuku?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
            final String name = "com.mysql.cj.jdbc.Driver";
            final String user = "root";
            final String password = "Jenny1210";

            // Connection conn = null;
            Class.forName(name);//指定连接类型
            conn = DriverManager.getConnection(url, user, password);//获取连接
            if (conn != null) {
                System.out.println("获取连接成功");
                // insert(conn);
            } else {
                System.out.println("获取连接失败");
            }   
            String sql="use shujuku;";
            PreparedStatement stmt=conn.prepareStatement(sql);
            stmt.executeQuery();

            sql="select CNAME,AVG(sc.gRADE) FROM SC,C WHERE SC.CNO=C.CNO GROUP BY SC.CNO;";
            stmt=conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            System.out.println(rs.getFetchSize());
            while(rs.next()){
                pingjunCJ CJ=new pingjunCJ();
                CJ.setAVGCJ(rs.getFloat(2));
                CJ.setCourse(rs.getString(1));
                list.add(CJ);
            }
        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return list;
    }
}