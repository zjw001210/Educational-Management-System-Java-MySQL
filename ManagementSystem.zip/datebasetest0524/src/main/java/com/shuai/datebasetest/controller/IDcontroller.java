package com.shuai.datebasetest.controller;
import com.shuai.datebasetest.Service.StudentService;
// import com.shuai.datebasetest.datebase.Student;
import com.shuai.datebasetest.datebase.studentinfo;
import com.fasterxml.jackson.core.JsonFactory;
import org.springframework.boot.Banner;
import org.springframework.stereotype.Controller;
import com.shuai.datebasetest.Service.StudentService;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.shuai.datebasetest.Service.infoServiceImpl;
import java.util.List;
@Controller
@Responsebody
public class IDcontroller {

    public static String Id=null;
}
