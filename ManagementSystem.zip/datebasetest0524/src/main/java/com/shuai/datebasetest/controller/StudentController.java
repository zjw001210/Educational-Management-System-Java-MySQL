package com.shuai.datebasetest.controller;
import com.shuai.datebasetest.Service.*;
import com.shuai.datebasetest.controller.Responsebody;
import com.shuai.datebasetest.datebase.*;
import com.fasterxml.jackson.core.JsonFactory;
import org.springframework.boot.Banner;
import org.springframework.stereotype.Controller;
import com.shuai.datebasetest.Service.StudentService;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
@Controller
@Responsebody
public class StudentController {
    // @RequestMapping("/info")
    // public studentinfo getStudent(){
    //     studentinfo student=new studentinfo();
    //     student.setSNO("S1");
    //     student.setSname("郑帅");
    //     student.setSex("男");
    //     student.setAge("22");
    //     return student;
    // }
    @RequestMapping("/login3")
    public String studentlist(Model model) throws Exception {
        infoServiceImpl infoService=new infoServiceImpl();
        KxuanService kxuanService=new KxuanService();
        YxuanService yxuanService=new YxuanService();
        CJService cjService=new CJService();
        List<studentinfo> studentinfoList=infoService.getInfolist();
        List<Kxuan> Kxuanlist=kxuanService.getInfolist();
        List<Yxuan> Yxuanlist=yxuanService.getInfolist();
        List<CHENGJI> Chengjilist=cjService.getInfolist();
        System.out.println(studentinfoList.size());
        model.addAttribute("studentinfolist",studentinfoList);
        model.addAttribute("Kxuanlist",Kxuanlist);
        model.addAttribute("Yxuanlist",Yxuanlist);
        model.addAttribute("Chengjilist",Chengjilist);
        return "Student";
    }
}
