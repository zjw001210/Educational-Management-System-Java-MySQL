package com.shuai.datebasetest.datebase;
public class StudentData {
    String SNO;
    String SNAME;
    String SEX;
    int age;
    String SDEPT;
    int FEES;
    public StudentData(String SNO)
    {
        this.SNO=SNO;
    }
}
