package com.shuai.datebasetest.Service;
import com.shuai.datebasetest.datebase.*;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.shuai.datebasetest.controller.HelloController;
@Service
public class CweihuService {
    public static int count;
    String sql="SELECT * FROM C";
    public List<Course> getInfolist() throws Exception {
        List<Course> list=new ArrayList<>();
        try {
            Connection conn=null;
            //加载驱动类


            final String url = "jdbc:mysql://1.116.199.203:3306/shujuku?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
            final String name = "com.mysql.cj.jdbc.Driver";
            final String user = "root";
            final String password = "Jenny1210";

            // Connection conn = null;
            Class.forName(name);//指定连接类型
            conn = DriverManager.getConnection(url, user, password);//获取连接
            if (conn != null) {
                System.out.println("获取连接成功");
                // insert(conn);
            } else {
                System.out.println("获取连接失败");
            }   
            PreparedStatement stmt=conn.prepareStatement("use shujuku");
            stmt.executeQuery();
            
             stmt=conn.prepareStatement(sql);
            ResultSet rs =stmt.executeQuery();
            while(rs.next()){
                count++;
                Course student1=new Course();
                System.out.println("课程名："+rs.getString("CNAME"));
                student1.setCNAME(rs.getString("CNAME"));
                student1.setCNO(rs.getString("CNO"));
                student1.setCDEPT(rs.getString("CDEPT"));
                student1.setTNO(rs.getString("TNO"));
                student1.setCREDIT(rs.getInt("CREDIT"));
                list.add(student1);
            }

        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return list;
    }
}