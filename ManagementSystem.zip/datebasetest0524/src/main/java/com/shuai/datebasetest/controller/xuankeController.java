package com.shuai.datebasetest.controller;
import com.shuai.datebasetest.datebase.Kxuan;
import com.shuai.datebasetest.datebase.StudentData;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.zip.CheckedInputStream;

@Controller
public class xuankeController {
    public static int r=0;
    @RequestMapping(value = "xuanke",method = RequestMethod.POST)
    public String xuanke(@RequestParam(value="xuanke") String CNO, Model model)throws Exception{
        int result=Checkexist(CNO);
        System.out.println("result"+result);
        if(result==0)
        {
            Insert(CNO);
        }
        model.addAttribute("jieguo",r);
        return "Student1";
    }
    public int Checkexist(String CNO) throws Exception{
        int flag=0;
        try {
            String sql=
                    "SELECT * FROM SC WHERE SC.CNO=? AND SC.SNO=?";
            String sql2=
                    "SELECT * FROM C where CNO=?";
            Connection conn=null;
            //加载驱动类
            final String url = "jdbc:mysql://1.116.199.203:3306/shujuku?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
            final String name = "com.mysql.cj.jdbc.Driver";
            final String user = "root";
            final String password = "Jenny1210";

            

            // Connection conn = null;
            Class.forName(name);//指定连接类型
            conn = DriverManager.getConnection(url, user, password);//获取连接
            if (conn != null) {
                System.out.println("获取连接成功");
                
            } else {
                System.out.println("获取连接失败");
            }   
            PreparedStatement stmt=conn.prepareStatement("use shujuku");
            stmt.executeQuery();
            stmt=conn.prepareStatement(sql);
            stmt.setString(1,CNO);
            stmt.setString(2,HelloController.Id);
            ResultSet rs =stmt.executeQuery();
            if(rs.next())
            {
                flag=1;
            }
            System.out.println("flag"+flag);

            PreparedStatement stmt2=conn.prepareStatement(sql2);
            stmt2.setString(1,CNO);
            ResultSet rs2 =stmt2.executeQuery();
            if(!rs2.next()){
                flag=1;
            }
            System.out.println("flag2"+flag);
        }

    catch (SQLException e){
        e.printStackTrace();
    }
            return flag;
    }
    public void Insert(String CNO) throws Exception{
        try {
            String sql="INSERT INTO SC(SNO,CNO)\n" +
                    "VALUES(?,?)";
            Connection conn=null;
            //加载驱动类
            
            final String url = "jdbc:mysql://1.116.199.203:3306/shujuku?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
            final String name = "com.mysql.cj.jdbc.Driver";
            final String user = "root";
            final String password = "Jenny1210";

            // Connection conn = null;
            Class.forName(name);//指定连接类型
            conn = DriverManager.getConnection(url, user, password);//获取连接
            if (conn != null) {
                System.out.println("获取连接成功");
                // insert(conn);
            } else {
                System.out.println("获取连接失败");
            }   
            PreparedStatement stmt=conn.prepareStatement("use shujuku");
            stmt.executeQuery();
            stmt=conn.prepareStatement(sql);
            stmt.setString(1,HelloController.Id);
            stmt.setString(2,CNO);
            r=stmt.executeUpdate();
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }
}
