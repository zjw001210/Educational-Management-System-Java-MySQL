package com.shuai.datebasetest.controller;
import com.shuai.datebasetest.datebase.StudentData;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.sql.*;
import java.util.ArrayList;

@Controller
public class HelloController {
    public static String Id=null;
    @RequestMapping("/login")
    public String hello(){
        return "login";
    }
    @RequestMapping(value = "/login2",method = RequestMethod.POST)
    public String login(@RequestParam(value="ID") String ID, @RequestParam(value="password") String password, Model model) throws Exception {
        Id=ID;
        String error="用户名或密码错误!请重新输入";
        System.out.println(Id);
        System.out.println(Checklogin(ID,password));
        if(Checklogin(ID,password).equals("SUCCESS"))
            if(Id.charAt(0) == 'S')
                return "Student1";
            else if(Id.charAt(0)=='T'){
                if (Id.equals("T0"))
                    return "ADMIN";
                else
                    return "cccc";}
            else
            {
                model.addAttribute("error",error);
                return "login";}
        else
        {   model.addAttribute("error",error);
            return "login";}
    }

    String Checklogin(String ID, String passwrd) throws Exception {
        {
            String sus = "SUCCESS";
            String fail = "Fail";
            String IDCheck;
            String PasswordCheck;
            String result="Fail";
            String sql="select password from S where SNO = ?";
            
            String sql2="select password from T where TNO=?";
            try {
                System.out.println(passwrd);
                Connection conn=null;
                ArrayList<StudentData> Studentchain=new ArrayList<StudentData>();
                //加载驱动类
                final String url = "jdbc:mysql://1.116.199.203:3306/shujuku?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
                final String name = "com.mysql.cj.jdbc.Driver";
                final String user = "root";
                final String password = "Jenny1210";

            // Connection conn = null;
            Class.forName(name);//指定连接类型
            conn = DriverManager.getConnection(url, user, password);//获取连接
            if (conn != null) {
                System.out.println("获取连接成功");
                // insert(conn);
            } else {
                System.out.println("获取连接失败");
            }   
                if(ID.charAt(0) == 'S'){
                    PreparedStatement stmt=conn.prepareStatement("use shujuku");
                    stmt.executeQuery();
                stmt=conn.prepareStatement(sql);
                stmt.setString(1,ID);
                ResultSet rs =stmt.executeQuery();
                while(rs.next()){
                    if(passwrd.equals(rs.getString("password").trim()))
                        result=sus;
                }}
                else {
                    PreparedStatement stmt=conn.prepareStatement("use shujuku");
                    stmt.executeQuery();
                    stmt=conn.prepareStatement(sql2);
                    stmt.setString(1,ID);
                    ResultSet rs =stmt.executeQuery();
                    while(rs.next()){
                        if(passwrd.equals(rs.getString("password").trim()))
                            result=sus;
                }}
            }
            catch (SQLException e){
                e.printStackTrace();
            }
            return result;
        }
    }

}