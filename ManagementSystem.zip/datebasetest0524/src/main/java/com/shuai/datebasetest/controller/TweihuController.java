package com.shuai.datebasetest.controller;
import com.shuai.datebasetest.Service.CweihuService;
import com.shuai.datebasetest.Service.TeacherService;
import com.shuai.datebasetest.Service.courseCJservice;
import com.shuai.datebasetest.datebase.Course;
import com.shuai.datebasetest.datebase.StudentData;
import com.shuai.datebasetest.datebase.Teacher;
import com.shuai.datebasetest.datebase.courseCJ;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
@Controller
public class TweihuController {
    public static int re;
    @RequestMapping("Tweihu1")
    public String Tweihu1(Model model) throws Exception {
        TeacherService teacherService=new TeacherService();
        List<Teacher>teacherList= teacherService.getInfolist();
        model.addAttribute("count",teacherList.size());
        model.addAttribute("teacherList",teacherList);
        return "Tweihu";
    }
    @RequestMapping(value = "/Tweihu2",method = RequestMethod.POST)
    public String Tweihu2(@RequestParam(value = "CNO") String TNO,
                          @RequestParam(value = "CNAME") String TNAME,@RequestParam(value = "CDEPT") String TDEPT,
                          @RequestParam(value = "TNO") String TCLASS,@RequestParam(value = "YUANXI") String password) throws Exception {
        Insert2(TNO,TNAME,TDEPT,TCLASS,password);
        return "TTTT";
    }
    @RequestMapping(value = "Tweihu3",method = RequestMethod.POST)
    public String Cweihu3(@RequestParam(value = "shanchu") String TNO) throws Exception {
        Delete2(TNO);
        return "TTTT";
    }
    public void Delete2(String TNO) throws Exception{

        String sql=
                "DELETE FROM T WHERE TNO=?";
        try {
            Connection conn=null;
            //加载驱动类
            final String url = "jdbc:mysql://1.116.199.203:3306/shujuku?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
            final String name = "com.mysql.cj.jdbc.Driver";
            final String user = "root";
            final String password = "Jenny1210";

            // Connection conn = null;
            Class.forName(name);//指定连接类型
            conn = DriverManager.getConnection(url, user, password);//获取连接
            if (conn != null) {
                System.out.println("获取连接成功");
                // insert(conn);
            } else {
                System.out.println("获取连接失败");
            }   
            PreparedStatement stmt=conn.prepareStatement("use shujuku");
            stmt.executeQuery();
            stmt=conn.prepareStatement(sql);
            stmt.setString(1,TNO);
            re=stmt.executeUpdate();
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }
    public void Insert2(String TNO,String TNAME,String TDEPT,String TCLASS,String password) throws Exception{
        try {
            String sql="INSERT INTO T(TNO,TNAME,TDEPT,TCLASS,Password)\n" +
                    "VALUES(?,?,?,?,?)";
            Connection conn=null;
            //加载驱动类
            final String url = "jdbc:mysql://1.116.199.203:3306/shujuku?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
            final String name = "com.mysql.cj.jdbc.Driver";
            final String user = "root";
            final String password2 = "Jenny1210";

            // Connection conn = null;
            Class.forName(name);//指定连接类型
            conn = DriverManager.getConnection(url, user, password2);//获取连接
            if (conn != null) {
                System.out.println("获取连接成功");
                // insert(conn);
            } else {
                System.out.println("获取连接失败");
            }   
            PreparedStatement stmt=conn.prepareStatement("use shujuku");
            stmt.executeQuery();
            stmt=conn.prepareStatement(sql);
            stmt.setString(1,TNO);
            stmt.setString(2,TNAME);
            stmt.setString(3,TDEPT);
            stmt.setString(4,TCLASS);
            stmt.setString(5,password);
            stmt.executeUpdate();
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }
}


