package com.shuai.datebasetest.controller;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;

import com.shuai.datebasetest.datebase.pingjunCJ;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import com.shuai.datebasetest.controller.fenbuController;
import com.shuai.datebasetest.datebase.pingjunCJ;
import javax.imageio.ImageIO;
import javax.swing.*;
public class Test {
    public void SHENGCHENG(List<pingjunCJ> list) {
        JDialog jd=new JDialog();
        jd.setBounds(50, 50, 1500, 800);
        jd.add(new fenbuController(list).getChartPanel());
        jd.setVisible(true);

        Container content = jd.getContentPane();
        //创建缓冲图片对象
        BufferedImage img = new BufferedImage(
                jd.getWidth(), jd.getHeight(), BufferedImage.TYPE_INT_RGB);
        //得到图形对象
        Graphics2D g2d = img.createGraphics();
        //将窗口内容面板输出到图形对象中
        content.printAll(g2d);
        //保存为图片
        File f = new File("/Users/a123/Desktop/datebasetest/src/main/resources/static/saveScreen.jpg");
        try {
            ImageIO.write(img, "jpg", f);
        } catch (IOException e) {
            e.printStackTrace();
        }
        //释放图形对象
        // g2d.dispose();
        // jd.setVisible(false);
    }
    }
