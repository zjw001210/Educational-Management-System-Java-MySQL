package com.shuai.datebasetest.datebase;
import com.shuai.datebasetest.bean.*;
import javax.persistence.Entity;
import javax.persistence.Table;
@Entity@Table(name="courseCJ")
public class courseCJ extends BaseBean{
    private String SNO;
    private String CJ;
    public String getSNO(){
        return SNO;
    }
    public void setSNO(String SNO){
        this.SNO=SNO;
    }
    public String getCJ(){
        return CJ;
    }
    public void setCJ(String CJ){
        this.CJ=CJ;
    }
}
