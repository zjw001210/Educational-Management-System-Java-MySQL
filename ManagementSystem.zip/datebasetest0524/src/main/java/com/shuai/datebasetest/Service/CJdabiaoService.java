package com.shuai.datebasetest.Service;
import com.shuai.datebasetest.datebase.*;
import org.springframework.stereotype.Service;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.shuai.datebasetest.controller.HelloController;

@Service
public class CJdabiaoService {
    public static float avgCJ;
    String sql=
            "SELECT SC.CNO,C.CNAME,SC.GRADE,C.CDEPT,T.TNAME FROM SC,C,T WHERE SC.SNO=? AND SC.CNO=C.CNO AND C.TNO=T.TNO";
    public List<CJdabiao> getInfolist() throws Exception{
        List<CJdabiao> list=new ArrayList<>();
        try {
            int count=0;
            float sum=0;
            Connection conn=null;
            //加载驱动类
            final String url = "jdbc:mysql://1.116.199.203:3306/shujuku?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
            final String name = "com.mysql.cj.jdbc.Driver";
            final String user = "root";
            final String password = "Jenny1210";

            // Connection conn = null;
            Class.forName(name);//指定连接类型
            conn = DriverManager.getConnection(url, user, password);//获取连接
            if (conn != null) {
                System.out.println("获取连接成功");
                // insert(conn);
            } else {
                System.out.println("获取连接失败");
            }   
            PreparedStatement stmt=conn.prepareStatement("use shujuku");
            stmt.executeQuery();

            stmt=conn.prepareStatement(sql);
            System.out.println(HelloController.Id);
            stmt.setString(1,HelloController.Id);
            ResultSet rs =stmt.executeQuery();
            while(rs.next()){
                CJdabiao student1=new CJdabiao();
                System.out.println(rs.getString("CNAME"));
                student1.setCNAME(rs.getString("CNAME"));
                student1.setCNO(rs.getString("CNO"));
                student1.setCJ(rs.getFloat("GRADE"));
                student1.setXF(rs.getString("CDEPT"));
                student1.setTname(rs.getString("TNAME"));
                list.add(student1);
                sum=sum+rs.getFloat("GRADE");
                count++;
            }
            avgCJ=sum/count;
        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return list;
    }
}