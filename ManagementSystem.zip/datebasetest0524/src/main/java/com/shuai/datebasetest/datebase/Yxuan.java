package com.shuai.datebasetest.datebase;
import com.shuai.datebasetest.bean.*;
import javax.persistence.Entity;
import javax.persistence.Table;
@Entity@Table(name="Yxuan")
public class  Yxuan extends BaseBean{
    private String CNO;
    private String CNAME;
    private String XUEFEN;
    private String YUANXI;
    private String TNAME;
    public String getCNO(){
        return CNO;
    }
    public void setCNO(String CNO){
        this.CNO=CNO;
    }
    public String getCNAME(){
        return CNAME;
    }
    public void setCNAME(String CNAME){
        this.CNAME=CNAME;
    }
    public String getXUEFEN(){
        return XUEFEN;
    }
    public void setXUEFEN(String XUEFEN)
    {
        this.XUEFEN=XUEFEN;
    }
    public String getYUANXI(){
        return YUANXI;
    }
    public void setYUANXI(String YUANXI){
        this.YUANXI = YUANXI;
    }
    public String getTNAME(){
        return TNAME;
    }
    public void setTNAME(String TNAME){
        this.TNAME=TNAME;
    }
}
