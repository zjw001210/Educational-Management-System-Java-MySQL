package com.shuai.datebasetest.controller;
import com.shuai.datebasetest.Service.courseCJservice;
import com.shuai.datebasetest.datebase.StudentData;
import com.shuai.datebasetest.datebase.courseCJ;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Controller
public class changeCJController {
    @RequestMapping(value = "/Admin3",method = RequestMethod.POST)
    public String Admin3(@RequestParam(value = "hahaha") String SNO, @RequestParam(value = "heiheihei2") String coursename,@RequestParam(value = "CJ") float CJ, Model model) throws Exception {
        //float CJ=Float.parseFloat(CJ2);
        Updaedate(SNO,coursename,CJ);
        courseCJservice coursecJservice=new courseCJservice();
        List<courseCJ> CJlist=coursecJservice.getInfolist(coursename);
        model.addAttribute("CJlist",CJlist);
        model.addAttribute("coursename",coursename);
        return "ADMIN";
    }
    public void Updaedate(String SNO,String Cname,float CJ){
        String sql=
                "UPDATE SC SET GRADE =?,POINT=? WHERE SNO=? AND CNO IN \n" +
                "(SELECT CNO FROM C WHERE CNAME=?)";
        try {
            Connection conn=null;
            //加载驱动类
            final String url = "jdbc:mysql://1.116.199.203:3306/shujuku?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
            final String name = "com.mysql.cj.jdbc.Driver";
            final String user = "root";
            final String password = "Jenny1210";

        // Connection conn = null;
        Class.forName(name);//指定连接类型
        conn = DriverManager.getConnection(url, user, password);//获取连接
        if (conn != null) {
            System.out.println("获取连接成功");
            // insert(conn);
        } else {
            System.out.println("获取连接失败");
        }   
        PreparedStatement stmt=conn.prepareStatement("use shujuku");
        stmt.executeQuery();
           
            stmt=conn.prepareStatement(sql);
            stmt.setFloat(1,CJ);
            stmt.setFloat(2,CHULI(CJ));
            stmt.setString(3,SNO);
            stmt.setString(4,Cname);
            stmt.executeUpdate();
        }
        catch (SQLException | ClassNotFoundException e){
            e.printStackTrace();
        }
    }
    public float CHULI(float CJ){
        if(CJ>=90)
            return 4.0f;
        else if(CJ>=85)
            return 3.7f;
        else if(CJ>=82)
            return 3.3f;
        else if(CJ>=78)
            return 3.0f;
        else if(CJ>=74)
            return 2.7f;
        else if(CJ>=70)
            return 2.3f;
        else if(CJ>=65)
            return 2.0f;
        else if(CJ>=60)
            return 1.0f;
        else
            return 0.0f;
    }
}