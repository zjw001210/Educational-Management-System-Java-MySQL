package com.shuai.datebasetest.datebase;
import com.shuai.datebasetest.bean.*;
import javax.persistence.Entity;
import javax.persistence.Table;
@Entity@Table(name="Teacher")
public class Teacher extends BaseBean{
    private String TNO;
    private  String TNAME;
    private  String TDEPT;
    private String TCLASS;
    private String Password;
    public String getTNO(){
        return TNO;
    }
    public String getTNAME(){
        return TNAME;
    }
    public String getTDEPT(){
        return TDEPT;
    }
    public String getTCLASS(){
        return TCLASS;
    }
    public String getPassword(){
        return Password;
    }
    public void setTNO(String tno){
        this.TNO=tno;
    }
    public void setTNAME(String tname){
        this.TNAME=tname;
    }
    public void setTDEPT(String tdept){
        this.TDEPT=tdept;
    }
    public void setTCLASS(String tclass){
        this.TCLASS=tclass;
    }
    public void setPassword(String password){
        this.Password=password;
    }
}
