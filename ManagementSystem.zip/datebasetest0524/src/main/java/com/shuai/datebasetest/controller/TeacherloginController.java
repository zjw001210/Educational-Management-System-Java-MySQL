package com.shuai.datebasetest.controller;
import com.shuai.datebasetest.datebase.Course;
import com.shuai.datebasetest.datebase.StudentData;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.shuai.datebasetest.Service.TecherloginService;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Controller
public class TeacherloginController {
    @RequestMapping("Teacher1")
    public String Teacher(Model model) throws Exception{
        TecherloginService techerloginService =new TecherloginService();
        List<Course> Courselist=techerloginService.getInfolist();
        model.addAttribute("Courselist",Courselist);
        System.out.println("老师"+HelloController.Id);
        System.out.println("老师名字"+findname());
        model.addAttribute("name",findname()) ;
    return "Teacher";
    }
    public static String findname() throws Exception{
        String sql="SELECT TNAME FROM T WHERE TNO=?";
        String Result=null;
        try {
            Connection conn=null;
            //加载驱动类
            final String url = "jdbc:mysql://1.116.199.203:3306/shujuku?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
            final String name = "com.mysql.cj.jdbc.Driver";
            final String user = "root";
            final String password = "Jenny1210";

            // Connection conn = null;
            Class.forName(name);//指定连接类型
            conn = DriverManager.getConnection(url, user, password);//获取连接
            if (conn != null) {
                System.out.println("获取连接成功");
                // insert(conn);
            } else {
                System.out.println("获取连接失败");
            }   
            PreparedStatement stmt=conn.prepareStatement("use shujuku");
            stmt.executeQuery();
            stmt=conn.prepareStatement(sql);
            stmt.setString(1,HelloController.Id);
            ResultSet rs =stmt.executeQuery();
            while(rs.next()){
                Result=rs.getString("TNAME");
            }
        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return Result;
    }
}