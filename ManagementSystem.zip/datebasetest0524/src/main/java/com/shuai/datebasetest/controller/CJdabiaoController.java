package com.shuai.datebasetest.controller;
import com.shuai.datebasetest.Service.CJdabiaoService;
import com.shuai.datebasetest.datebase.CJdabiao;
import com.shuai.datebasetest.datebase.Kxuan;
import com.shuai.datebasetest.datebase.StudentData;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.CheckedInputStream;
import com.shuai.datebasetest.Service.infoServiceImpl;
@Controller
public class CJdabiaoController {
    @RequestMapping("/CJ")
    public String CJlist(Model model) throws Exception{
        CJdabiaoService cJdabiaoService=new CJdabiaoService();
        List<CJdabiao> CJdabiaoList=cJdabiaoService.getInfolist();
        model.addAttribute("Scorelist",CJdabiaoList);
        model.addAttribute("avgCJ",CJdabiaoService.avgCJ);
        model.addAttribute("SNO",HelloController.Id);
        model.addAttribute("name",infoServiceImpl.name);
        return "Score";
    }
}
