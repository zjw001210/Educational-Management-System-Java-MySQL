package com.shuai.datebasetest.controller;
import com.shuai.datebasetest.datebase.Kxuan;
import com.shuai.datebasetest.datebase.StudentData;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.zip.CheckedInputStream;
@Controller
public class TuikeController {
    public static int rr;
    @RequestMapping(value = "tuike",method = RequestMethod.POST)
    public String xuanke(@RequestParam(value="tuike") String CNO, Model model)throws Exception{
        int result=Checkexist2(CNO);
        if(result==1)
        {
            Delete(CNO);
        }
        model.addAttribute("jieguo2",rr);
        return "Student1";
    }
    public int Checkexist2(String CNO)throws Exception{
        int flag=0;
        try {
            String sql=
                    "SELECT * FROM SC WHERE CNO=? AND SNO=? AND GRADE IS NULL";
            Connection conn=null;
            //加载驱动类
            final String url = "jdbc:mysql://1.116.199.203:3306/shujuku?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
            final String name = "com.mysql.cj.jdbc.Driver";
            final String user = "root";
            final String password = "Jenny1210";

            
            Class.forName(name);//指定连接类型
            conn = DriverManager.getConnection(url, user, password);//获取连接
            if (conn != null) {
                System.out.println("获取连接成功");
                // insert(conn);
            } else {
                System.out.println("获取连接失败");
            }   
            PreparedStatement stmt=conn.prepareStatement("use shujuku");
            stmt.executeQuery();
            stmt=conn.prepareStatement(sql);
            stmt.setString(1,CNO);
            stmt.setString(2,HelloController.Id);
            ResultSet rs =stmt.executeQuery();
            if(rs.next()){
                flag=1;
            }
        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return flag;
    }
    public void Delete(String CNO) throws Exception{

        String sql=
                "DELETE FROM SC WHERE CNO=? AND SNO=?";
        try {
            Connection conn=null;
            //加载驱动类

            final String url = "jdbc:mysql://1.116.199.203:3306/shujuku?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
            final String name = "com.mysql.cj.jdbc.Driver";
            final String user = "root";
            final String password = "Jenny1210";

            
            Class.forName(name);//指定连接类型
            conn = DriverManager.getConnection(url, user, password);//获取连接
            if (conn != null) {
                System.out.println("获取连接成功");
                // insert(conn);
            } else {
                System.out.println("获取连接失败");
            }   
            PreparedStatement stmt=conn.prepareStatement("use shujuku");
            stmt.executeQuery();
            
            stmt=conn.prepareStatement(sql);
            stmt.setString(1,CNO);
            stmt.setString(2,HelloController.Id);
            rr=stmt.executeUpdate();
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }
}