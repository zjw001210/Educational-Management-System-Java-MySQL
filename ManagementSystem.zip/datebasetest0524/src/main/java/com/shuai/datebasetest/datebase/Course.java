package com.shuai.datebasetest.datebase;
import com.shuai.datebasetest.bean.*;
import javax.persistence.Entity;
import javax.persistence.Table;
@Entity@Table(name="Course")
public class Course extends BaseBean{
    private String CNO;
    private String CNAME;
    private String CDEPT;
    private String TNO;
    private int CREDIT;
    public String getCNO(){
        return CNO;
    }
    public String getCNAME(){
        return CNAME;
    }
    public String getTNO(){
        return TNO;
    }
    public int getCREDIT(){
        return CREDIT;
    }
    public String getCDEPT(){
        return CDEPT;
    }
    public void setCNO(String CNO){
        this.CNO=CNO;
    }
    public void setCNAME(String CNAME){
        this.CNAME=CNAME;
    }
    public void setCDEPT(String CDEPT){
        this.CDEPT=CDEPT;
    }
    public void setTNO(String TNO){
        this.TNO=TNO;
    }
    public void setCREDIT(int credit){
        this.CREDIT=credit;
    }
}
