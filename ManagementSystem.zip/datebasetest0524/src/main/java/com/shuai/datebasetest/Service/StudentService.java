package com.shuai.datebasetest.Service;
import com.shuai.datebasetest.datebase.studentinfo;
import org.springframework.boot.autoconfigure.security.SecurityProperties;

import java.util.List;

public interface StudentService {
    /**
     * 保存用户对象
     * @param studentinfo
     */
  List<studentinfo>getInfolist() throws Exception;

}
