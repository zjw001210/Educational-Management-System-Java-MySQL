package com.shuai.datebasetest.controller;
import com.shuai.datebasetest.Service.CweihuService;
import com.shuai.datebasetest.Service.TeacherService;
import com.shuai.datebasetest.Service.courseCJservice;
import com.shuai.datebasetest.datebase.Course;
import com.shuai.datebasetest.datebase.StudentData;
import com.shuai.datebasetest.datebase.Teacher;
import com.shuai.datebasetest.datebase.courseCJ;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
@Controller
public class CweihuController {
    @RequestMapping("Cweihu1")
    public String Cweihu1(Model model) throws Exception {
        CweihuService cweihuService=new CweihuService();
        TeacherService teacherService=new TeacherService();
        List<Course>courselist =cweihuService.getInfolist();
        List<Teacher>teacherList= teacherService.getInfolist();
        model.addAttribute("courselist",courselist);
        model.addAttribute("count",courselist.size());
        model.addAttribute("teacherList",teacherList);
        return "Cweihu";
    }
    @RequestMapping(value = "/Cweihu2",method = RequestMethod.POST)
    public String Cweihu2(@RequestParam(value = "CNO") String CNO,
                          @RequestParam(value = "CNAME") String CNAME,@RequestParam(value = "CDEPT") String CDEPT,
                          @RequestParam(value = "TNO") String TNO,@RequestParam(value = "YUANXI") String YUANXI) throws Exception {
        Insert(CNO,CNAME,CDEPT,YUANXI,TNO);
        return "cWEIHU1";
    }
    @RequestMapping(value = "Cweihu3",method = RequestMethod.POST)
    public String Cweihu3(@RequestParam(value = "shanchu") String CNO) throws Exception {
        Delete(CNO);
        return "cWEIHU1";
    }
    public void Delete(String CNO) throws Exception{

        String sql="use shujuku;";
                
        try {
            Connection conn=null;
            //加载驱动类
            
            final String url = "jdbc:mysql://1.116.199.203:3306/shujuku?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
            final String name = "com.mysql.cj.jdbc.Driver";
            final String user = "root";
            final String password = "Jenny1210";

            // Connection conn = null;
            Class.forName(name);//指定连接类型
            conn = DriverManager.getConnection(url, user, password);//获取连接
            if (conn != null) {
                System.out.println("获取连接成功");
                // insert(conn);
            } else {
                System.out.println("获取连接失败");
            }
            
            PreparedStatement stmt=conn.prepareStatement(sql);
            stmt.executeQuery();

            sql="DELETE FROM C WHERE CNO=?";
            stmt=conn.prepareStatement(sql);
            stmt.setString(1,CNO);
            stmt.executeUpdate();
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }
    public void Insert(String CNO,String CNAME,String CDEPT,String YUANXI,String TNO) throws Exception{
        try {
            String sql="INSERT INTO C(CNO,CNAME,CDEPT,CREDIT,TNO)\n" +
                    "VALUES(?,?,?,?,?)";
            Connection conn=null;
            //加载驱动类


            final String url = "jdbc:mysql://1.116.199.203:3306/shujuku?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
            final String name = "com.mysql.cj.jdbc.Driver";
            final String user = "root";
            final String password = "Jenny1210";

            // Connection conn = null;
            Class.forName(name);//指定连接类型
            conn = DriverManager.getConnection(url, user, password);//获取连接
            if (conn != null) {
                System.out.println("获取连接成功");
                // insert(conn);
            } else {
                System.out.println("获取连接失败");
            }   
            PreparedStatement stmt=conn.prepareStatement("use shujuku");
            stmt.executeQuery();
            
            stmt=conn.prepareStatement(sql);
            stmt.setString(1,CNO);
            stmt.setString(2,CNAME);
            stmt.setString(3,CDEPT);
            stmt.setString(4,YUANXI);
            stmt.setString(5,TNO);
            stmt.executeUpdate();
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }
}
