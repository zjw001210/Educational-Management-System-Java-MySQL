package com.shuai.datebasetest.Service;
import com.shuai.datebasetest.datebase.*;
import org.springframework.stereotype.Service;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.shuai.datebasetest.controller.HelloController;
@Service
public class courseCJservice {
    String sql="Select SNO,GRADE FROM SC,C WHERE C.CNAME=? AND C.CNO=SC.CNO";
    public List<courseCJ> getInfolist(String coursename) throws Exception{
        List<courseCJ> list=new ArrayList<>();
        try {
            int count=0;
            float sum=0;
            Connection conn=null;
            //加载驱动类
            final String url = "jdbc:mysql://1.116.199.203:3306/shujuku?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
            final String name = "com.mysql.cj.jdbc.Driver";
            final String user = "root";
            final String password = "Jenny1210";

            // Connection conn = null;
            Class.forName(name);//指定连接类型
            conn = DriverManager.getConnection(url, user, password);//获取连接
            if (conn != null) {
                System.out.println("获取连接成功");
                // insert(conn);
            } else {
                System.out.println("获取连接失败");
            }   
            PreparedStatement stmt=conn.prepareStatement("use shujuku");
            stmt.executeQuery();

            stmt=conn.prepareStatement(sql);
            stmt.setString(1,coursename);
            ResultSet rs =stmt.executeQuery();
            while (rs.next()){
                courseCJ student1=new courseCJ();
                student1.setCJ(rs.getString("GRADE"));
                student1.setSNO(rs.getString("SNO"));
                list.add(student1);
            }
        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return list;
    }
}