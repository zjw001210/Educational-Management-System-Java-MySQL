package com.shuai.datebasetest.Service;
import com.shuai.datebasetest.datebase.StudentData;
import com.shuai.datebasetest.datebase.studentinfo;
import org.springframework.stereotype.Service;
import com.shuai.datebasetest.datebase.Kxuan;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.shuai.datebasetest.controller.HelloController;
import com.shuai.datebasetest.datebase.CHENGJI;
@Service
public class CJService{
    String sql=
            "SELECT SC.CNO,CNAME,GRADE,POINT FROM SC,C WHERE SC.SNO=? AND SC.CNO=C.CNO;";
    public List<CHENGJI> getInfolist() throws Exception {
        List<CHENGJI> list=new ArrayList<>();
        try {
            Connection conn=null;
            //加载驱动类


            final String url = "jdbc:mysql://1.116.199.203:3306/shujuku?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
            final String name = "com.mysql.cj.jdbc.Driver";
            final String user = "root";
            final String password = "Jenny1210";

            // Connection conn = null;
            Class.forName(name);//指定连接类型
            conn = DriverManager.getConnection(url, user, password);//获取连接
            if (conn != null) {
                System.out.println("获取连接成功");
                // insert(conn);
            } else {
                System.out.println("获取连接失败");
            }   
            PreparedStatement stmt=conn.prepareStatement("use shujuku");
            stmt.executeQuery();
            stmt=conn.prepareStatement(sql);
            System.out.println(HelloController.Id);
            stmt.setString(1,HelloController.Id);
            ResultSet rs =stmt.executeQuery();
            System.out.println(rs.getRow());
            while(rs.next()){
                CHENGJI student1=new CHENGJI();
                System.out.println(rs.getString("CNAME"));
                student1.setCNAME(rs.getString("CNAME"));
                student1.setCNO(rs.getString("CNO"));
                student1.setThisCJ(rs.getString("GRADE"));
                student1.setPoint(rs.getString("POINT"));
                list.add(student1);
            }
        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return list;
    }
}