package com.shuai.datebasetest.controller;
import com.shuai.datebasetest.Service.CweihuService;
import com.shuai.datebasetest.Service.TeacherService;
import com.shuai.datebasetest.Service.courseCJservice;
import com.shuai.datebasetest.datebase.Course;
import com.shuai.datebasetest.datebase.StudentData;
import com.shuai.datebasetest.datebase.Teacher;
import com.shuai.datebasetest.datebase.courseCJ;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.shuai.datebasetest.Service.SweihuService;
import com.shuai.datebasetest.datebase.studentinfo;
@Controller
public class SweihuController {
    @RequestMapping("Sweihu1")
    public String Sweihu1(Model model) throws Exception {
        SweihuService sweihuService=new SweihuService();
        List<studentinfo>teacherList= sweihuService.getInfolist();
        model.addAttribute("count",teacherList.size());
        model.addAttribute("studentList",teacherList);
        return "Sweihu";
    }
    @RequestMapping(value = "/Sweihu2",method = RequestMethod.POST)
    public String Tweihu2(@RequestParam(value = "SNO") String SNO,
                          @RequestParam(value = "SNAME") String SNAME,@RequestParam(value = "SEX") String SEX,
                          @RequestParam(value = "AGE") String AGE,@RequestParam(value = "yuanxi") String YUANXI,@RequestParam(value ="Password") String Password) throws Exception {
        Insert3(SNO,SNAME,SEX,AGE,YUANXI,Password);
        return "SSSS";
    }
    @RequestMapping(value = "Sweihu3",method = RequestMethod.POST)
    public String Tweihu3(@RequestParam(value = "shanchu") String SNO) throws Exception {
        Delete3(SNO);
        return "SSSS";
    }
    public void Delete3(String SNO) throws Exception{

        String sql=
                "DELETE FROM S WHERE SNO=?";
        try {
            Connection conn=null;
            //加载驱动类
            final String url = "jdbc:mysql://1.116.199.203:3306/shujuku?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
            final String name = "com.mysql.cj.jdbc.Driver";
            final String user = "root";
            final String password = "Jenny1210";

            // Connection conn = null;
            Class.forName(name);//指定连接类型
            conn = DriverManager.getConnection(url, user, password);//获取连接
            if (conn != null) {
                System.out.println("获取连接成功");
                // insert(conn);
            } else {
                System.out.println("获取连接失败");
            }   
            PreparedStatement stmt=conn.prepareStatement("use shujuku");
            stmt.executeQuery();
            stmt=conn.prepareStatement(sql);
            stmt.setString(1,SNO);
            stmt.executeUpdate();
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }
    public void Insert3(String SNO,String SNAME,String SEX,String AGE,String YUANXI,String Password) throws Exception{
        try {
            String sql="INSERT INTO S(SNO,SNAME,SEX,AGE,SDEPT,password)\n" +
                    "VALUES(?,?,?,?,?,?)";
            Connection conn=null;
            //加载驱动类

            final String url = "jdbc:mysql://1.116.199.203:3306/shujuku?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
            final String name = "com.mysql.cj.jdbc.Driver";
            final String user = "root";
            final String password = "Jenny1210";

            // Connection conn = null;
            Class.forName(name);//指定连接类型
            conn = DriverManager.getConnection(url, user, password);//获取连接
            if (conn != null) {
                System.out.println("获取连接成功");
                // insert(conn);
            } else {
                System.out.println("获取连接失败");
            }   
            PreparedStatement stmt=conn.prepareStatement("use shujuku");
            stmt.executeQuery();

            stmt=conn.prepareStatement(sql);
            stmt.setString(1,SNO);
            stmt.setString(2,SNAME);
            stmt.setString(3,SEX);
            stmt.setString(4,AGE);
            stmt.setString(5,YUANXI);
            stmt.setString(6,Password);
            stmt.executeUpdate();
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }
}


