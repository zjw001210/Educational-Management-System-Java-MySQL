package com.shuai.datebasetest.datebase;
import com.shuai.datebasetest.bean.*;
import javax.persistence.Entity;
import javax.persistence.Table;
@Entity@Table(name="pingjunCJ")
public class pingjunCJ extends BaseBean{
    private String Course;
    private float AVGCJ;
    public String getCourse(){
        return Course;
    }
    public void setCourse(String Course){
        this.Course=Course;
    }
    public float getAVGCJ(){
        return AVGCJ;
    }
    public void setAVGCJ(float avgcj){
        this.AVGCJ=avgcj;
    }
}
