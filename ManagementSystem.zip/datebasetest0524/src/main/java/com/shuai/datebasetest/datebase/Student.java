package com.shuai.datebasetest.datebase;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.ArrayList;
//import com.google.gson.Gson;
//import com.google.gson.GsonBuilder;
import java.sql.*;
import java.util.ArrayList;
@RestController
public class Student {
    @RequestMapping("hello")
    public String Getdata(String[] args)
            throws Exception{
        try {
            Connection conn=null;
            ArrayList<StudentData> Studentchain=new ArrayList<StudentData>();
            //加载驱动类


            final String url = "jdbc:mysql://1.116.199.203:3306/shujuku?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
            final String name = "com.mysql.cj.jdbc.Driver";
            final String user = "root";
            final String password = "1079624493Fl$";

            // Connection conn = null;
            Class.forName(name);//指定连接类型
            conn = DriverManager.getConnection(url, user, password);//获取连接
            if (conn != null) {
                System.out.println("获取连接成功");
                // insert(conn);
            } else {
                System.out.println("获取连接失败");
            }

            PreparedStatement stmt=conn.prepareStatement("use shujuku;");
            
            stmt.executeQuery();
            stmt=conn.prepareStatement("select sno from S;");
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Studentchain.add(new StudentData(rs.getString("SNO")));
                System.out.println(rs.getString("SNO"));
            }
            
        }
        catch (SQLException e){
            e.printStackTrace();
        }

        return "你好";
    }
}
