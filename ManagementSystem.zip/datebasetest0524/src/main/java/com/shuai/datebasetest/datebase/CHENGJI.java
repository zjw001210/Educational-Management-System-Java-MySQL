package com.shuai.datebasetest.datebase;
import com.shuai.datebasetest.bean.*;
import javax.persistence.Entity;
import javax.persistence.Table;
@Entity@Table(name="CHENGJI")
public class  CHENGJI extends BaseBean{
    private String CNO;
    private String CNAME;
    private String thisCJ;
    private String point;
    public String getCNO(){
        return CNO;
    }
    public void setCNO(String CNO){
        this.CNO=CNO;
    }
    public void setCNAME(String CNAME){
        this.CNAME=CNAME;
    }
    public String getCNAME(){
        return CNAME;
    }
    public String getThisCJ(){
        return thisCJ;
    }
    public void setThisCJ(String thisCJ){
        this.thisCJ=thisCJ;
    }
    public String getPoint(){
        return point;
    }
    public void setPoint(String point){
        this.point=point;
    }
}
