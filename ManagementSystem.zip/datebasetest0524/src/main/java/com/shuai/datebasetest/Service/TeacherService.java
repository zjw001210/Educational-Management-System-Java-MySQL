package com.shuai.datebasetest.Service;
import com.shuai.datebasetest.datebase.*;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.shuai.datebasetest.controller.HelloController;
@Service
public class TeacherService {
    public static int count;
    String sql="SELECT * FROM T";
    public List<Teacher> getInfolist() throws Exception {
        List<Teacher> list=new ArrayList<>();
        try {
            Connection conn=null;
            //加载驱动类
            final String url = "jdbc:mysql://1.116.199.203:3306/shujuku?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
            final String name = "com.mysql.cj.jdbc.Driver";
            final String user = "root";
            final String password = "Jenny1210";

            // Connection conn = null;
            Class.forName(name);//指定连接类型
            conn = DriverManager.getConnection(url, user, password);//获取连接
            if (conn != null) {
                System.out.println("获取连接成功");
                // insert(conn);
            } else {
                System.out.println("获取连接失败");
            }   
            PreparedStatement stmt=conn.prepareStatement("use shujuku");
            stmt.executeQuery(); 
            
            stmt=conn.prepareStatement(sql);
            ResultSet rs =stmt.executeQuery();
            while(rs.next()){
                Teacher student1=new Teacher();
                System.out.println("老师： "+rs.getString("TNAME"));
                student1.setTNAME(rs.getString("TNAME"));
                student1.setTCLASS(rs.getString("TCLASS"));
                student1.setTDEPT(rs.getString("TDEPT"));
                student1.setTNO(rs.getString("TNO"));
                student1.setPassword(rs.getString("password"));
                list.add(student1);
            }
        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return list;
    }
}

