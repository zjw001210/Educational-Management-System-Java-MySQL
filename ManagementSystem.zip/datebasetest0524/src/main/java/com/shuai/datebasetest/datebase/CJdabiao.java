package com.shuai.datebasetest.datebase;
import com.shuai.datebasetest.bean.*;
import javax.persistence.Entity;
import javax.persistence.Table;
@Entity@Table(name="CJdabiao")
public class CJdabiao extends BaseBean{
    private String CNO;
    private String CNAME;
    private float  CJ;
    private String XF;
    private String Tname;
    public String getCNO(){
        return CNO;
    }
    public void setCNO(String CNO)
    {
        this.CNO=CNO;
    }
    public String getCNAME(){
        return CNAME;
    }
    public void setCNAME(String CNAME){
        this.CNAME=CNAME;
    }
    public float getCJ(){
        return CJ;
    }
    public void setCJ(float CJ){
        this.CJ=CJ;
    }
    public String getXF(){
        return XF;
    }
    public String getTname(){
        return Tname;
    }
    public void setXF(String XF){
        this.XF=XF;
    }
    public void setTname(String TNAME){
        this.Tname=TNAME;
    }
}
