package com.shuai.datebasetest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatebasetestApplicationTests {

    @Test
    void contextLoads() {
    }

}
